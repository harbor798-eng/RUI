(function (global) {
  const PAGE_TITLES = {
    'home': 'AI 快速回复',
    'chat-history': '核对记录',
    'detail-analysis': '详细分析',
    'settings': '设置',
    'ai-observation': 'AI 观察'
  };
  const BACK_PAGES = { 'chat-history': true, 'detail-analysis': true, 'ai-observation': true, 'settings': true };

  const pages = {
    'home': renderHome,
    'ai-observation': renderDeepObservation,
    'settings': renderSettings,
    'chat-history': renderChatHistory,
    'detail-analysis': renderDetailAnalysis
  };

  function normalizeStrategy(s) {
    if (!s) return 'NATURAL';
    const k = String(s).trim();
    if (k === 'NATURAL' || k === '自然') return 'NATURAL';
    if (k === 'PROACTIVE' || k === 'ACTIVE' || k === '主动') return 'PROACTIVE';
    if (k === 'LIGHT_FLIRT' || k === 'SLIGHTLY_FLIRTATIOUS' || k === '轻微暧昧') return 'LIGHT_FLIRT';
    return k;
  }
  const STRATEGY_LABEL = { 'NATURAL':'自然', 'PROACTIVE':'主动', 'LIGHT_FLIRT':'轻微暧昧' };
  const STRATEGY_ORDER = ['NATURAL','PROACTIVE','LIGHT_FLIRT'];
  let quickReplyState = { generated: false, byStrategy: {} };

  /* ===== Header / scroll collapse ===== */
  let lastScrollTop = 0;
  let currentScrollEl = null;
  const scrollbarTimers = new WeakMap();
  function pokeScrollbar(el) {
    if (!el) return;
    el.classList.add('scrollbar-active');
    console.log('[ScrollbarDebug] element=', el.id || el.className, 'active=true', 'scrollTop=', el.scrollTop, 'sh=', el.scrollHeight, 'ch=', el.clientHeight);
    clearTimeout(scrollbarTimers.get(el));
    scrollbarTimers.set(el, setTimeout(() => {
      el.classList.remove('scrollbar-active');
      console.log('[ScrollbarDebug] fade-out element=', el.id || el.className);
    }, 800));
  }
  function bindHeaderScroll(scrollEl) {
    const header = document.getElementById('jeve-header');
    if (!header) return;
    currentScrollEl = scrollEl;
    console.log('[HeaderDebug] bind scroll element=', scrollEl ? (scrollEl.id || scrollEl.className) : 'none');
    if (!scrollEl) return;
    scrollEl.onscroll = () => {
      const st = scrollEl.scrollTop;
      if (st > lastScrollTop + 8 && st > 60) {
        header.classList.add('hidden');
      } else if (st < lastScrollTop - 4) {
        header.classList.remove('hidden');
      }
      lastScrollTop = st;
      console.log('[HeaderDebug] scrollTop=', st, 'headerHidden=', header.classList.contains('hidden'));
      pokeScrollbar(scrollEl);
    };
  }

  function updateHeader(page) {
    document.getElementById('header-title').textContent = PAGE_TITLES[page] || 'JEVE';
    const back = document.getElementById('header-back');
    back.classList.toggle('visible', !!BACK_PAGES[page]);
    const settingsBtn = document.getElementById('header-settings');
    if (settingsBtn) settingsBtn.classList.toggle('hidden', page === 'settings');
    const bottomNav = document.getElementById('bottom-nav');
    if (bottomNav) bottomNav.style.display = (page === 'chat-history') ? 'none' : '';
    lastScrollTop = 0;
    document.getElementById('jeve-header').classList.remove('hidden');
  }

  /* ===== Pages ===== */
  function renderHome() {
    return `
      <div class="skill-row">
        Skill
        <select class="skill-selector" id="skill-select">
          <option value="QUICK_REPLY">快速回复</option>
        </select>
      </div>
      <div class="qr-toolbar">
        <button id="qr-generate" class="primary">生成回复</button>
        <span id="qr-status" class="muted"></span>
      </div>
      <div id="qr-grid" class="qr-grid">
        <p class="page-placeholder">点击"生成回复"获取候选。</p>
      </div>`;
  }

  function renderSettings() {
    return `<div class="settings-list">
      <div class="qr-card"><h3>AI 配置</h3><p class="muted">服务商、API Key、Base URL、模型（由桌面端管理）。</p></div>
      <div class="qr-card"><h3>实时采集上下文</h3>
        <select class="skill-selector" id="ctx-len">
          <option value="10">10 条</option>
          <option value="20">20 条</option>
          <option value="50">50 条</option>
        </select></div>
      <div class="qr-card"><h3>AI 档案</h3><p class="muted">由 Profile 页面管理：<a href="http://127.0.0.1:18080/profile.html" target="_blank">打开档案页</a></p></div>
      <div class="qr-card"><h3>AI 观察</h3><button class="primary" data-page="ai-observation">进入深度观察</button></div>
      <div class="qr-card"><h3>Skill 管理</h3><p class="muted">当前 Skill：快速回复。</p></div>
      <div class="qr-card"><h3>关于</h3><p class="muted">JEVE · Web UI V1。</p></div>
    </div>`;
  }

  function renderChatHistory() {
    return `<div class="chat-page">
      <div id="ch-status" class="page-placeholder">正在加载…</div>
      <div id="ch-list" class="chat-stream"></div>
      <div class="ch-inputbar">
        <button id="ch-add" class="ch-add" title="添加历史消息">＋</button>
        <input id="ch-input" placeholder="输入消息……" />
        <button id="ch-send" class="primary">发送</button>
      </div>
    </div>`;
  }

  function renderDeepObservation() {
    setTimeout(() => {
      fetch('http://127.0.0.1:18080/api/deep-observation/data-range').then(r=>r.json()).then(d => {
        const el = document.getElementById('do-range');
        if (!el) return;
        el.textContent = d.hasData ? (d.first + ' ~ ' + d.last) : '暂无聊天记录';
        if (!d.hasData) { const b = document.getElementById('do-start'); if (b) b.disabled = true; }
      }).catch(() => { const el = document.getElementById('do-range'); if (el) el.textContent = '加载失败'; });
    }, 0);
    return `<p class="muted">这段关系一路发生了什么？</p>
      <div class="qr-grid">
        <div class="qr-card">
          <label><input type="radio" name="do-range" value="ALL" checked> 全部聊天记录</label><br>
          <label><input type="radio" name="do-range" value="RECENT_YEAR"> 最近一年</label><br>
          <label><input type="radio" name="do-range" value="RECENT_3_MONTHS"> 最近三个月</label><br>
          <label><input type="radio" name="do-range" value="CUSTOM"> 自定义</label>
        </div>
        <div class="qr-card"><span class="muted">当前聊天数据：</span><span id="do-range">加载中…</span></div>
        <button id="do-start" class="primary">开始深度观察</button>
        <div id="do-status" class="muted"></div>
        <div id="do-report"></div>
      </div>`;
  }

  function renderDetailAnalysis() {
    setTimeout(() => runDetailAnalysis(), 0);
    return `<div id="da-status" class="page-placeholder">正在分析最近 7 天的互动……</div>
      <div id="da-result"></div>`;
  }

  /* ===== Detail analysis ===== */
  async function runDetailAnalysis() {
    try {
      const res = await fetch('http://127.0.0.1:18080/api/detail-analysis', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: '{}'
      });
      const data = await res.json();
      const status = document.getElementById('da-status');
      if (!data.success) { status.textContent = '暂时无法完成分析：' + (data.status || data.error || ''); return; }
      if (data.status === 'NO_DATA') { status.textContent = data.message || '当前没有可分析的聊天记录。'; return; }
      status.textContent = '';
      const r = data.result || {};
      const poss = r.possibilities || [];
      const conf = poss[0] && poss[0].estimatedProbability != null ? Math.round(poss[0].estimatedProbability * 100) : null;
      const obs = r.observations || [];
      const recs = r.recommendations || [];
      const emotions = (r.emotions || []).slice(0, 4).map(e => ({
        label: e.emotion || '其他',
        pct: Math.round((e.estimatedProbability || 0) * 100)
      }));

      document.getElementById('da-result').innerHTML = `
        <div class="da-section">
          <h3>对方可能意图</h3>
          <div class="da-card">${escapeHtml(poss[0] ? poss[0].content : '暂无判断')}</div>
        </div>
        ${conf != null ? `<div class="da-section"><h3>判断把握</h3><div class="da-card da-confidence">判断把握 · ${conf}%</div></div>` : ''}
        <div class="da-section">
          <h3>当前状态</h3>
          <div class="da-card">${donutHtml(emotions)}</div>
        </div>
        <div class="da-section">
          <h3>判断依据</h3>
          <div class="da-card">${obs.map(o => '• ' + escapeHtml(o.content)).join('<br>') || '暂无依据'}</div>
        </div>
        <div class="da-section">
          <h3>AI 建议</h3>
          <div class="da-card">${escapeHtml(recs[0] ? recs[0].content : '暂无建议')}</div>
        </div>`;
    } catch (e) {
      document.getElementById('da-status').textContent = '请求失败：' + e.message;
    }
  }

  function donutHtml(items) {
    if (!items.length) return '<span class="muted">暂无情绪数据</span>';
    const colors = ['#6d5bd0', '#e8a838', '#4fb286', '#b8b8c2'];
    const total = items.reduce((s, x) => s + (x.pct || 0), 0) || 1;
    let acc = 0;
    const R = 30, C = 2 * Math.PI * R;
    const arcs = items.map((it, i) => {
      const frac = it.pct / total;
      const len = frac * C;
      const dash = `${len} ${C - len}`;
      const offset = -acc * C;
      acc += frac;
      return `<circle r="${R}" cx="36" cy="36" fill="none" stroke="${colors[i % colors.length]}" stroke-width="8" stroke-dasharray="${dash}" stroke-dashoffset="${offset}"/>`;
    }).join('');
    const top = items[0];
    return `<div class="donut-wrap">
      <div class="donut">
        <svg width="72" height="72">${arcs}</svg>
        <div class="donut-center"><span class="pct">${top.pct}%</span><span class="lbl">${escapeHtml(top.label)}</span></div>
      </div>
      <div class="donut-legend">
        ${items.map((it, i) => `<div class="row"><span class="dot" style="background:${colors[i%colors.length]}"></span>${escapeHtml(it.label)}<span class="pct">${it.pct}%</span></div>`).join('')}
      </div>
    </div>`;
  }

  /* ===== Navigate ===== */
  function navigate(page) {
    console.log('[WebUI][INFO] navigate:', page);
    const fn = pages[page];
    if (!fn) return;
    updateHeader(page);
    const main = document.getElementById('main-content');
    main.innerHTML = fn();
    main.classList.toggle('no-scroll', page === 'chat-history');
    lastScrollTop = 0;
    if (page === 'chat-history') {
      bindHeaderScroll(null);
    } else {
      bindHeaderScroll(main);
    }
    document.querySelectorAll('[data-page]').forEach(b => {
      b.classList.toggle('active', b.dataset.page === page);
    });
    document.getElementById('session-back')?.remove();
    const backBtn = document.getElementById('header-back');
    backBtn.onclick = () => navigate('home');
    if (page === 'home') bindHome();
    if (page === 'ai-observation') bindDeepObs();
    if (page === 'chat-history') loadChatHistory();
  }

  /* ===== Chat history ===== */
  let chState = { loaded: new Set(), hasMore: true, loading: false, beforeTime: null, beforeId: null };

  async function loadChatHistory() {
    const status = document.getElementById('ch-status');
    const list = document.getElementById('ch-list');
    chState = { loaded: new Set(), hasMore: true, loading: false, beforeTime: null, beforeId: null };
    try {
      const res = await fetch('http://127.0.0.1:18080/api/chat-history?size=50');
      const d = await res.json();
      if (!d.success) { status.textContent = '聊天记录加载失败。'; return; }
      let msgs = (d.messages || []).slice().reverse();
      if (!msgs.length) { status.textContent = '暂无聊天记录'; } else { status.textContent = ''; }
      list.innerHTML = msgs.map(m => { chState.loaded.add(m.id); return bubble(m); }).join('');
      chState.hasMore = d.hasMore;
      if (msgs.length) {
        const oldest = msgs[0];
        chState.beforeTime = oldest.time; chState.beforeId = oldest.id;
      }
      requestAnimationFrame(() => { list.scrollTop = list.scrollHeight; });
      bindChatActions(list);
      const header = document.getElementById('jeve-header');
      list.onscroll = async () => {
        const st = list.scrollTop;
        if (st > lastScrollTop + 8 && st > 60) header.classList.add('hidden');
        else if (st < lastScrollTop - 4) header.classList.remove('hidden');
        lastScrollTop = st;
        pokeScrollbar(list);
        if (list.scrollTop <= 30 && !chState.loading && chState.hasMore && chState.beforeTime) {
          chState.loading = true;
          const oldH = list.scrollHeight, oldT = list.scrollTop;
          try {
            const r = await fetch(`http://127.0.0.1:18080/api/chat-history?size=50&beforeTime=${encodeURIComponent(chState.beforeTime)}&beforeId=${chState.beforeId}`);
            const j = await r.json();
            let older = (j.messages || []).slice().reverse();
            const fresh = older.filter(m => !chState.loaded.has(m.id));
            fresh.forEach(m => chState.loaded.add(m.id));
            if (fresh.length) {
              list.insertAdjacentHTML('afterbegin', fresh.map(bubble).join(''));
              chState.hasMore = j.hasMore;
              const o = fresh[0]; chState.beforeTime = o.time; chState.beforeId = o.id;
              requestAnimationFrame(() => { list.scrollTop = oldT + (list.scrollHeight - oldH); });
              bindChatActions(list);
            }
          } finally { chState.loading = false; }
        }
      };
      const doSend = async () => {
        const input = document.getElementById('ch-input');
        const text = (input.value||'').trim();
        if (!text) return;
        console.log('[ChatHistory] sending message');
        await fetch('http://127.0.0.1:18080/api/chat-history', {method:'POST',headers:{'Content-Type':'application/json'},
          body: JSON.stringify({speaker:'ME', content:text})});
        input.value = '';
        input.focus();
        loadChatHistory();
      };
      const send = document.getElementById('ch-send');
      if (send) send.onclick = doSend;
      const input = document.getElementById('ch-input');
      if (input) input.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); doSend(); } };
      document.getElementById('ch-add').onclick = () => openMsgModal('ME', null);
    } catch (e) {
      status.textContent = '聊天记录加载失败，请稍后重试。';
    }
  }

  function bubble(m) {
    const me = m.speaker === 'ME';
    return `<div class="bubble-row ${me?'me':'other'}" data-id="${m.id}" data-time="${escapeHtml(m.time||'')}">
      <div class="bubble ${me?'bubble-me':'bubble-other'}">
        <div class="muted">${me?'我':'对方'} · ${escapeHtml((m.time||'').replace('T',' ').slice(0,16))}</div>
        <div>${escapeHtml(m.content||'')}</div>
      </div>
    </div>`;
  }

  /* ===== Right-click context menu ===== */
  let ctxTargetId = null;
  function bindChatActions(root) {
    root.querySelectorAll('.bubble-row').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        ctxTargetId = row.dataset.id;
        console.log('[ContextMenuDebug] isMessage=true target=', e.target.tagName, 'menuShown=true');
        const menu = document.getElementById('ctx-menu');
        menu.style.display = 'block';
        menu.style.left = e.clientX + 'px';
        menu.style.top = e.clientY + 'px';
      });
    });
  }
  document.addEventListener('contextmenu', (e) => {
    const menu = document.getElementById('ctx-menu');
    if (!menu || menu.style.display !== 'block') return;
    if (!e.target.closest || !e.target.closest('.bubble-row')) {
      console.log('[ContextMenuDebug] non-message target=', e.target.tagName, 'menu hidden');
      menu.style.display = 'none';
    }
  });
  document.addEventListener('click', (e) => {
    const menu = document.getElementById('ctx-menu');
    if (menu && menu.style.display === 'block' && !menu.contains(e.target)) menu.style.display = 'none';
  });
  document.getElementById('ctx-menu').addEventListener('click', async (e) => {
    const act = e.target.dataset.act;
    document.getElementById('ctx-menu').style.display = 'none';
    if (!ctxTargetId) return;
    if (act === 'edit') {
      const row = document.querySelector(`.bubble-row[data-id="${ctxTargetId}"]`);
      const cur = row ? row.querySelector('.bubble > div:last-child').textContent : '';
      const text = prompt('编辑内容', cur);
      if (text == null) return;
      await fetch('http://127.0.0.1:18080/api/chat-history/'+ctxTargetId, {method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:text})});
      loadChatHistory();
    } else if (act === 'add') {
      const row = document.querySelector(`.bubble-row[data-id="${ctxTargetId}"]`);
      openMsgModal('OTHER', row ? row.dataset.time : null);
    }
  });

  /* ===== Add message modal ===== */
  function openMsgModal(defaultSpeaker, presetTime) {
    document.getElementById('msg-modal').style.display = 'flex';
    document.querySelector(`input[name="m-speaker"][value="${defaultSpeaker}"]`).checked = true;
    const dateEl = document.getElementById('m-date');
    const timeEl = document.getElementById('m-time');
    let base;
    if (presetTime) base = presetTime;
    else base = new Date(Date.now() - new Date().getTimezoneOffset()*60000).toISOString();
    dateEl.value = base.slice(0,10);
    timeEl.value = (base.slice(11,16)) || '12:00';
    document.getElementById('m-content').value = '';
    document.getElementById('m-content').focus();
  }
  document.getElementById('m-cancel').onclick = () => { document.getElementById('msg-modal').style.display = 'none'; };
  document.getElementById('msg-modal').addEventListener('click', (e) => {
    if (e.target.id === 'msg-modal') e.target.style.display = 'none';
  });
  document.getElementById('m-save').onclick = async () => {
    const speaker = document.querySelector('input[name="m-speaker"]:checked').value;
    const date = document.getElementById('m-date').value;
    const time = document.getElementById('m-time').value;
    const combinedTime = date + 'T' + (time || '12:00') + ':00';
    const content = document.getElementById('m-content').value.trim();
    if (!content) return;
    console.log('[AddMessageDebug] speaker=', speaker, 'date=', date, 'time=', time, 'combinedTime=', combinedTime);
    await fetch('http://127.0.0.1:18080/api/chat-history', {method:'POST',headers:{'Content-Type':'application/json'},
      body: JSON.stringify({speaker, time: combinedTime, content})});
    document.getElementById('msg-modal').style.display = 'none';
    loadChatHistory();
  };

  /* ===== Deep observation ===== */
  function bindDeepObs() {
    const btn = document.getElementById('do-start');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      document.getElementById('do-status').textContent = '正在进行深度观察……';
      const rangeEl = document.querySelector('input[name=do-range]:checked');
      const range = rangeEl ? rangeEl.value : 'ALL';
      try {
        const res = await fetch('http://127.0.0.1:18080/api/deep-observation', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({range})
        });
        const d = await res.json();
        if (!d.success) { document.getElementById('do-status').textContent = '失败：' + d.status; btn.disabled = false; return; }
        document.getElementById('do-status').textContent = '报告已生成';
        document.getElementById('do-report').innerHTML = `
          <div class="qr-card">
            <button id="do-save">保存报告</button>
            <iframe sandbox src="http://127.0.0.1:18080/api/deep-observation/report?reportId=${d.reportId}" style="width:100%;height:800px;border:none;border-radius:8px;background:#fff"></iframe>
          </div>`;
        document.getElementById('do-save').addEventListener('click', async () => {
          await fetch('http://127.0.0.1:18080/api/deep-observation/save', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({reportId: d.reportId})
          });
        });
      } catch (e) {
        document.getElementById('do-status').textContent = '请求失败：' + e.message;
        btn.disabled = false;
      }
    });
  }

  /* ===== Quick reply ===== */
  function bindHome() {
    const btn = document.getElementById('qr-generate');
    if (btn) btn.addEventListener('click', generate);
    if (quickReplyState.generated) renderQuickCards(quickReplyState.byStrategy);
  }
  function renderQuickCards(byStrategy) {
    const grid = document.getElementById('qr-grid');
    if (!grid) return;
    grid.innerHTML = STRATEGY_ORDER.map(s => `
      <div class="qr-card">
        <div class="qr-head">
          <h3>${STRATEGY_LABEL[s]}</h3>
          <button class="qr-refresh" data-strategy="${s}" title="刷新">↻</button>
        </div>
        <div class="qr-text">${escapeHtml(byStrategy[s] || '（无候选）')}</div>
        <div class="qr-actions"><button data-use="${escapeHtml(byStrategy[s] || '')}">使用</button></div>
      </div>`).join('');
    grid.querySelectorAll('[data-use]').forEach(b => {
      b.addEventListener('click', async () => {
        await fetch('http://127.0.0.1:18080/api/clipboard', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:b.dataset.use})});
        b.textContent='已复制';
      });
    });
    grid.querySelectorAll('.qr-refresh').forEach(b => {
      b.addEventListener('click', async (e) => {
        e.stopPropagation();
        const s = b.dataset.strategy;
        b.disabled = true;
        try {
          const r = await fetch('http://127.0.0.1:18080/api/quick-reply/refresh', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({strategy:s})});
          const d = await r.json();
          if (d.success && d.candidate) {
            quickReplyState.byStrategy[s] = d.candidate.replyText;
            renderQuickCards(quickReplyState.byStrategy);
          }
        } finally { b.disabled = false; }
      });
    });
  }

  async function generate() {
    const status = document.getElementById('qr-status');
    document.getElementById('qr-generate').disabled = true;
    status.textContent = '正在生成回复……';
    try {
      const res = await fetch('http://127.0.0.1:18080/api/quick-reply', {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: '{}'
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || data.status || 'failed');
      const byStrategy = {};
      (data.candidates || []).forEach(c => {
        byStrategy[normalizeStrategy(c.strategy)] = c.replyText;
      });
      quickReplyState = { generated: true, byStrategy };
      renderQuickCards(byStrategy);
      status.textContent = '完成';
    } catch (e) {
      status.textContent = '生成失败：' + e.message;
    } finally {
      document.getElementById('qr-generate').disabled = false;
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  global.JeveRouter = { navigate };
})(window);
